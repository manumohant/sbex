<?php

/**
 * Possible delivery status of SMS sent previously
 */
class SMSStatus {
    const QUEUED = "queued";
    const DELIVERED = "delivered";
    const FAILED = "failed";
    const ERROR = "error";
}

