<?php
class payroll_history extends Eloquent {
	public $timestamps = false;
	protected $table = 'payroll_history';
}