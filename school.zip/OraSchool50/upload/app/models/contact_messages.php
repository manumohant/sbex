<?php
class contact_messages extends Eloquent {
	public $timestamps = false;
	protected $table = "contact_messages";
}