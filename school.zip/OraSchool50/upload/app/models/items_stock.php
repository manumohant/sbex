<?php
class items_stock extends Eloquent {
	public $timestamps = false;
	protected $table = "items_stock";
}