<?php
class frontend_pages extends Eloquent {
	public $timestamps = false;
	protected $table = 'frontend_pages';
}