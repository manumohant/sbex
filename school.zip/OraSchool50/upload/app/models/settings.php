<?php
class settings extends Eloquent {
	public $timestamps = false;
	protected $table = 'settings';
}