<?php
class online_exams extends Eloquent {
	public $timestamps = false;
	protected $table = 'online_exams';
}
