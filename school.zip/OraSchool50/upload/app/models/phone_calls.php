<?php
class phone_calls extends Eloquent {
	public $timestamps = false;
	protected $table = "phone_calls";
}