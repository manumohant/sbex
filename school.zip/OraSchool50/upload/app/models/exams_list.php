<?php
class exams_list extends Eloquent {
	public $timestamps = false;
	protected $table = 'exams_list';
}
