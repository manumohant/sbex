<?php
class online_exams_grades extends Eloquent {
	public $timestamps = false;
	protected $table = 'online_exams_grades';
}
