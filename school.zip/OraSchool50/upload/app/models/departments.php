<?php
class departments extends Eloquent {
	public $timestamps = false;
	protected $table = "departments";
}