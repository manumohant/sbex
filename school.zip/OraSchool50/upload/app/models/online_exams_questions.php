<?php
class online_exams_questions extends Eloquent {
	public $timestamps = false;
	protected $table = "online_exams_questions";
}