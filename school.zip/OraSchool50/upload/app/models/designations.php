<?php
class designations extends Eloquent {
	public $timestamps = false;
	protected $table = "designations";
}