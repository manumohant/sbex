<?php
class visitors extends Eloquent {
	public $timestamps = false;
	protected $table = "visitors";
}