<?php
class fee_group extends Eloquent {
	public $timestamps = false;
	protected $table = 'fee_group';
}
