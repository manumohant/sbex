<?php
class student_docs extends Eloquent {
	public $timestamps = false;
	protected $table = 'student_docs';
}
