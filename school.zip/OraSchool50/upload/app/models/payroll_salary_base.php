<?php
class payroll_salary_base extends Eloquent {
	public $timestamps = false;
	protected $table = 'payroll_salary_base';
}