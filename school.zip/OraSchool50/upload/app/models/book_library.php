<?php
class book_library extends Eloquent {
	public $timestamps = false;
	protected $table = 'book_library';
}
