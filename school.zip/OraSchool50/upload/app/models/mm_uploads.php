<?php
class mm_uploads extends Eloquent {
	public $timestamps = false;
	protected $table = 'mm_uploads';
}
