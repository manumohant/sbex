<?php
class mailsms_templates extends Eloquent {
	public $timestamps = false;
	protected $table = 'mailsms_templates';
}
