<?php
class vacation extends Eloquent {
	public $timestamps = false;
	protected $table = 'vacation';
}
