<?php
class complaints extends Eloquent {
	public $timestamps = false;
	protected $table = "complaints";
}