<?php
class suppliers extends Eloquent {
	public $timestamps = false;
	protected $table = "suppliers";
}